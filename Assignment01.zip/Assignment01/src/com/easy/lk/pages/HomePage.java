package com.easy.lk.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class HomePage {

	private WebDriver driver;

	By searchdealbtn = By.id("search_deal");
	By selectdropdown = By.id("ProductCategoryId");

	public HomePage(WebDriver driver) {
		this.driver = driver;
	}

	public void selectDropDown() {
		Select dropdown = new Select(driver.findElement(selectdropdown));
		dropdown.selectByVisibleText("Electronics");

	}

	public void clickSearchButton() {
		driver.findElement(searchdealbtn).click();
	}

}
