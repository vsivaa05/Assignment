package com.easy.lk.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SearchResultPage {

	private WebDriver driver;

	By addcart1 = By
			.xpath("(//a[@class='btn btn-success btn-lg btn-raised ripple-effect btn-block'])[2]");
	By ok1 = By.xpath("/html/body/div[5]/div[7]/div/button");
	By addcart2 = By
			.xpath("(//a[@class='btn btn-success btn-lg btn-raised ripple-effect btn-block'])[4]");
	By shoppingcart = By.xpath("//*[@id='shoppingCartDropDown']");
	By viewcart = By.xpath("//*[@id='mini-shopping-cart']/div/div/a");

	public SearchResultPage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickFirstAddtoCard() {
		driver.findElement(addcart1).click();
	}

	public void clickOkButton() {
		driver.findElement(ok1).click();
	}

	public void clickSecondAddCard() {
		driver.findElement(addcart2).click();

	}

	public void clickShoppingCartBtn() {
		driver.findElement(shoppingcart).click();
	}

	public void clickViewCartBtn() {
		driver.findElement(viewcart).click();
	}
}
