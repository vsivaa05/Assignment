package com.easy.lk.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class ShoppingCartPage {

	private WebDriver driver;

	By qty = By.xpath("//*[@id='[0].Quantity']");
	By updatecart = By.xpath("//*[@id='updateCart']/input[1]");
	By msg = By.xpath("//*[@id='toast-container']/div/div[3]");
	By total = By
			.xpath("//*[@id='page']/div/form/div[1]/div[2]/div[1]/div/table/tbody/tr[3]/td[6]");

	public ShoppingCartPage(WebDriver driver) {
		this.driver = driver;
	}

	public void changeQty() {
		driver.findElement(qty).clear();
		driver.findElement(qty).sendKeys("2");
	}

	public void clickUpdateCartBtn() {
		driver.findElement(updatecart).click();
	}

	public void verifySuccessMsg() {
		String expectedMessage = "Cart details updated sucessfully, 2 seconds ago";
		String message = driver.findElement(msg).getText();
		Assert.assertTrue(message.contains(expectedMessage));
	}

	public void verifyTotal() {

		String to = driver.findElement(total).getText();
		String expected = "Rs. 2,970.00";
		Assert.assertEquals(to, expected);

	}
}
