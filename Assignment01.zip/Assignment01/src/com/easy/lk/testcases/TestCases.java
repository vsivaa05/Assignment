package com.easy.lk.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.easy.lk.pages.HomePage;
import com.easy.lk.pages.SearchResultPage;
import com.easy.lk.pages.ShoppingCartPage;
import com.easy.lk.util.PropertyFileReader;

public class TestCases {

	private WebDriver driver;

	@BeforeMethod
	public void setupBrowser() {
		System.setProperty("webdriver.chrome.driver",
				PropertyFileReader.readProperty("webDriverPath"));

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(PropertyFileReader.readProperty("webUrl"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test
	public void testCase01() {
		
		HomePage hp = new HomePage(driver);
		hp.selectDropDown();
		hp.clickSearchButton();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		SearchResultPage sr = new SearchResultPage(driver);
		sr.clickFirstAddtoCard();
		sr.clickOkButton();
		sr.clickSecondAddCard();
		sr.clickOkButton();
		sr.clickShoppingCartBtn();
		sr.clickViewCartBtn();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		ShoppingCartPage sc = new ShoppingCartPage(driver);
		sc.changeQty();
		sc.clickUpdateCartBtn();
		sc.verifySuccessMsg();
		sc.verifyTotal();

	}

	@AfterMethod
	public void endTest() {
		// driver.quit();
	}
}
