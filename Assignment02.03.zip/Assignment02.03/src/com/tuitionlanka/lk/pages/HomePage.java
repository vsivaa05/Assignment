package com.tuitionlanka.lk.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.tuitionlanka.lk.util.PropertyFileReader;

public class HomePage {

	private WebDriver driver;

	By registerbtn = By.xpath("//*[@id='t3-header']/div/div[1]/div/ul/li[2]/a");

	public HomePage(WebDriver driver) {
		this.driver = driver;
	}

	public void verifyPage() {

		Assert.assertEquals(
				PropertyFileReader.readProperty("homePageTitle"),
				driver.getTitle());
	}

	public void clickRegisterBtn() {
		driver.findElement(registerbtn).click();
	}

}
