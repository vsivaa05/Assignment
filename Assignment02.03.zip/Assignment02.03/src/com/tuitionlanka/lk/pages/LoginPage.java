package com.tuitionlanka.lk.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.tuitionlanka.lk.util.ExcelReader;
import com.tuitionlanka.lk.util.PropertyFileReader;

public class LoginPage {

	private WebDriver driver;

	By uname = By.name("username");
	By pw = By.name("password");
	By loginBtn = By.name("submit");

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}
	

	public void verifypage() {

		Assert.assertEquals(
				PropertyFileReader.readProperty("loginPageTitle"),
				driver.getTitle());
	}

	public void setUserName() {

		driver.findElement(uname).sendKeys(ExcelReader.userName);
	}
	public void setPw(){
		driver.findElement(pw).sendKeys(ExcelReader.password);
	}
	
	public void clickLogin(){
		driver.findElement(loginBtn).click();
	}

}
