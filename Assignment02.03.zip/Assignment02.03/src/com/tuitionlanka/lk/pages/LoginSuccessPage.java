package com.tuitionlanka.lk.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.tuitionlanka.lk.util.ExcelReader;
import com.tuitionlanka.lk.util.PropertyFileReader;

public class LoginSuccessPage {

	WebDriver driver;

	By subject = By.name("ad_Subject");
	By town = By.name("ad_town");
	By year = By.name("ad_year");
	By phone = By.name("ad_phone");
	By address = By.name("ad_address");
	By classtype = By.name("ad_Classtype");
	By district = By.id("ad_city");
	By tittle = By.id("ad_headline");
	By description = By.id("ad_text");
	By category = By.name("cats");
	By addcat = By.name("addcat");
	By savebtn = By
			.xpath("//*[@id='adsmanager_fieldset']/table/tbody/tr[21]/td[1]/input");

	public LoginSuccessPage(WebDriver driver) {
		this.driver = driver;
	}

	public void setSubject() {
		driver.findElement(subject).sendKeys(ExcelReader.subject);
	}

	public void setyear() {
		driver.findElement(year).sendKeys(ExcelReader.year);
	}

	public void setPhone() {
		driver.findElement(phone).sendKeys(ExcelReader.phone);
	}

	public void setAddress() {
		driver.findElement(address).sendKeys(ExcelReader.address);
	}

	public void setClass() {
		Select classTypeDropDown = new Select(driver.findElement(classtype));
		classTypeDropDown.selectByVisibleText(ExcelReader.classtype);
	}

	public void setDistrict() {

		Select districtDropDown = new Select(driver.findElement(district));
		districtDropDown.selectByVisibleText(ExcelReader.district);
	}

	public void setTown() {
		Select townDropDown = new Select(driver.findElement(town));
		townDropDown.selectByVisibleText(ExcelReader.town);
	}

	public void setClassType() {
		driver.findElement(classtype).sendKeys(ExcelReader.classtype);
	}

	public void setTittle() {
		driver.findElement(tittle).sendKeys(ExcelReader.tittle);
	}

	public void setDescription() {
		driver.findElement(description).sendKeys(ExcelReader.description);
		System.out.println(ExcelReader.category);
	}

	public void setCategory() {

		Select categoryDropDown = new Select(driver.findElement(category));
		categoryDropDown.selectByVisibleText(ExcelReader.category);
		driver.findElement(addcat).click();
	}

	public void clickSaveBtn() {
		driver.findElement(savebtn).click();
	}

	public void verifySuccessMsg() {

		Assert.assertTrue(driver.getPageSource().contains(
				PropertyFileReader.readProperty("loginSuccessMsg")));
	}

}
