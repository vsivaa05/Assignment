package com.tuitionlanka.lk.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.tuitionlanka.lk.util.PropertyFileReader;

public class RegisterSelectionPage {

	private WebDriver driver;

	By regteacher = By.xpath("//*[@id='k2Container']/div[2]/div[1]/div[3]/a");

	public RegisterSelectionPage(WebDriver driver) {
		this.driver = driver;
	}

	public void verifypage() {
		Assert.assertEquals(
				PropertyFileReader.readProperty("regSelectionPageTitle"),
				driver.getTitle());
	}

	public void clickRegTeacher() {
		driver.findElement(regteacher).click();
	}

}
