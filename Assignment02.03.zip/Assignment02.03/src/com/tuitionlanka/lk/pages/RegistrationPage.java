package com.tuitionlanka.lk.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.tuitionlanka.lk.util.ExcelReader;

public class RegistrationPage {
	
	private WebDriver driver;

	By fname = By.id("firstname");
	By lname = By.id("lastname");
	By uname = By.id("username");
	By pw = By.id("password");
	By vpw = By.id("password__verify");
	By district = By.id("cb_district");
	By town = By.id("cb_town");
	By email = By.id("email");
	By phone = By.id("phone");
	By subject = By.id("cb_subjects__");
	By regbtn = By
			.xpath("//*[@id='registrationTable']/tbody/tr[25]/td/span/input");

	public RegistrationPage(WebDriver driver) {
		this.driver = driver;
	}

	public void setFirstName() throws Exception {
	    driver.findElement(fname).sendKeys(ExcelReader.firstName);
	}
	public void setLastName() throws Exception {
		driver.findElement(lname).sendKeys(ExcelReader.lastName);
	}
	public void setUserName() throws Exception {
		driver.findElement(uname).sendKeys(ExcelReader.userName);
	}
	public void setPassWord() throws Exception {
		driver.findElement(pw).sendKeys(ExcelReader.password);
	}
	public void setVerifyPw() throws Exception {
		driver.findElement(vpw).sendKeys(ExcelReader.verifyPassword);
	}
	public void setDistrict() throws Exception {
		driver.findElement(district).sendKeys(ExcelReader.district);
	}
	public void setTown() throws Exception {
		driver.findElement(town).sendKeys(ExcelReader.town);
	}
	public void setEmail() throws Exception {
		driver.findElement(email).sendKeys(ExcelReader.email);
	}
	public void setPhone() throws Exception {
		driver.findElement(phone).sendKeys(ExcelReader.phone);
	}
	public void setSubject() throws Exception {
		driver.findElement(subject).sendKeys(ExcelReader.subject);

	}

	public void clickRegBtn() {
		driver.findElement(regbtn).click();
	}

}
