package com.tuitionlanka.lk.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.tuitionlanka.lk.util.PropertyFileReader;

public class RegistrationSuccessPage {

	private WebDriver driver;

	By login = By.xpath("//*[@id='t3-header']/div/div[1]/div/ul/li[1]/a");

	public RegistrationSuccessPage(WebDriver driver) {
		this.driver = driver;
	}

	public void verifySuccessMsg() {

		Assert.assertTrue(driver.getPageSource().contains(PropertyFileReader.readProperty("regSuccessMsg")));
	}

	public void clickLogin() {
		driver.findElement(login).click();
	}
}
