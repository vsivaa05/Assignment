package com.tuitionlanka.lk.testcases;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.tuitionlanka.lk.pages.HomePage;
import com.tuitionlanka.lk.pages.LoginPage;
import com.tuitionlanka.lk.pages.LoginSuccessPage;
import com.tuitionlanka.lk.pages.RegisterSelectionPage;
import com.tuitionlanka.lk.pages.RegistrationPage;
import com.tuitionlanka.lk.pages.RegistrationSuccessPage;
import com.tuitionlanka.lk.util.PropertyFileReader;

public class TestCases {

	private WebDriver driver;

	@BeforeTest
	public void setupBrowser() throws Exception {

		System.setProperty("webdriver.chrome.driver",
				PropertyFileReader.readProperty("webDriverPath"));

		driver = new ChromeDriver();
		driver.manage().window().maximize();

		FileReader filereader = new FileReader("util.txt");
		BufferedReader bufferreader = new BufferedReader(filereader);
		String line = bufferreader.readLine();
		driver.get(line);
		bufferreader.close();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test(priority = 1)
	public void tc001_VerifyHomepage() throws Exception {

		HomePage hp = new HomePage(driver);
		hp.verifyPage();
	}

	@Test(priority = 2)
	public void tc002_ClickRegBtnTest() {
		HomePage hp = new HomePage(driver);
		hp.clickRegisterBtn();
	}

	@Test(priority = 3)
	public void tc003_VerifyRegisterSelectionPage() throws Exception {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		RegisterSelectionPage regSelPage = new RegisterSelectionPage(driver);
		regSelPage.verifypage();

	}

	@Test(priority = 4)
	public void tc004_TestClickRegTecherBtn() {
		RegisterSelectionPage regSelPage = new RegisterSelectionPage(driver);
		regSelPage.clickRegTeacher();
	}

	@Test(priority = 5)
	public void tc005_TestFillDetailForm() throws Exception {
		RegistrationPage regPage = new RegistrationPage(driver);
		regPage.setFirstName();
		regPage.setLastName();
		regPage.setUserName();
		regPage.setPassWord();
		regPage.setVerifyPw();
		regPage.setDistrict();
		regPage.setTown();
		regPage.setEmail();
		regPage.setPhone();
		regPage.setSubject();
	}

	@Test(priority = 6)
	public void tc006_VerifyClickRegBtn() {
		RegistrationPage regPage = new RegistrationPage(driver);
		regPage.clickRegBtn();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test(priority = 7)
	public void tc007_VerifySuccessMsg() {
		RegistrationSuccessPage regSuccessPage = new RegistrationSuccessPage(
				driver);
		regSuccessPage.verifySuccessMsg();
	}

	@Test(priority = 8)
	public void tc008_VerifyClickLogin() {
		RegistrationSuccessPage regSuccessPage = new RegistrationSuccessPage(
				driver);

		regSuccessPage.clickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test(priority = 9)
	public void tc009_VerifyLoginPage() {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.verifypage();
	}

	@Test(priority = 10)
	public void tc010_VerifyClicklogin() {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.setUserName();
		loginPage.setPw();
		loginPage.clickLogin();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test(priority = 11)
	public void tc011_VerifyFillForm() {
		LoginSuccessPage loginSuccessPage = new LoginSuccessPage(driver);
		loginSuccessPage.setCategory();
		loginSuccessPage.setSubject();
		loginSuccessPage.setClassType();
		loginSuccessPage.setDistrict();
		loginSuccessPage.setTown();
		loginSuccessPage.setTittle();
		loginSuccessPage.setDescription();
		loginSuccessPage.setyear();
		loginSuccessPage.setPhone();

	}

	@Test(priority = 12)
	public void tc012_VerifyClickSaveBTn() {
		LoginSuccessPage loginSuccessPage = new LoginSuccessPage(driver);
		loginSuccessPage.clickSaveBtn();
	}

	@Test(priority = 13)
	public void tc013_VerifySuccessMsg() {
		LoginSuccessPage loginSuccessPage = new LoginSuccessPage(driver);
		loginSuccessPage.verifySuccessMsg();
	}

	@AfterTest
	public void endTest() {
		driver.quit();
	}
}
