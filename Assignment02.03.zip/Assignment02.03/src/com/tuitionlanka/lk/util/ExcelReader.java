package com.tuitionlanka.lk.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

	public static String firstName;
	public static String lastName;
	public static String userName;
	public static String password;
	public static String verifyPassword;
	public static String district;
	public static String town;
	public static String email;
	public static String phone;
	public static String subject;
	public static String year;
	public static String address;
	public static String tittle;
	public static String classtype;
	public static String description;
	public static String category;

	static {

		File file = new File("C:\\Users\\shan\\Desktop\\sivaa.xlsx");

		FileInputStream fis;
		XSSFWorkbook wb;
		try {
			fis = new FileInputStream(file);
			wb = new XSSFWorkbook(fis);
			
			XSSFSheet sheet = wb.getSheetAt(0);

			firstName = sheet.getRow(0).getCell(0).getStringCellValue();
			lastName = sheet.getRow(0).getCell(1).getStringCellValue();
			userName = sheet.getRow(0).getCell(2).getStringCellValue();
			password = sheet.getRow(0).getCell(3).getStringCellValue();
			verifyPassword = sheet.getRow(0).getCell(4).getStringCellValue();
			district = sheet.getRow(0).getCell(5).getStringCellValue();
			town = sheet.getRow(0).getCell(6).getStringCellValue();
			email = sheet.getRow(0).getCell(7).getStringCellValue();
			phone = sheet.getRow(0).getCell(8).getStringCellValue();
			subject = sheet.getRow(0).getCell(9).getStringCellValue();
			year = sheet.getRow(0).getCell(10).getStringCellValue();
			address = sheet.getRow(0).getCell(11).getStringCellValue();
			classtype = sheet.getRow(0).getCell(12).getStringCellValue();
			tittle = sheet.getRow(0).getCell(13).getStringCellValue();
			description = sheet.getRow(0).getCell(14).getStringCellValue();
			category = sheet.getRow(0).getCell(15).getStringCellValue();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
