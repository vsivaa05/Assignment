package com.tuitionlanka.lk.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyFileReader {
	
	private static Properties prop = new Properties();
	private static InputStream input = null;

	static {

		try {

			input = new FileInputStream("tuitionlanka.properties");

			// load a properties file
			prop.load(input);

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static String readProperty(String key) {
		
		return prop.getProperty(key);

	}

}
